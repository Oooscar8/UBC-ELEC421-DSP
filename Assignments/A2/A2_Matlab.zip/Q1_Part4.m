% Time vector for continuous signal
t = -0.04:0.0001:0.04;

% Sampling frequency
Fs = 75;

% Time vector for samples
t_sampled = -0.04:1/Fs:0.04;

% Original signal (from Part 3)
xa_original = 3*cos(100*pi*t);
x_sampled_original = 3*cos(100*pi*t_sampled);

% Aliased signal (for Part 4)
F_aliased = 25;
xa_aliased = 3*cos(2*pi*F_aliased*t);
x_sampled_aliased = 3*cos(2*pi*F_aliased*t_sampled);

% Plotting
figure('Position', [100, 100, 600, 500]);

% Original signal (Part 3)
subplot(2,1,1);
plot(t, xa_original, 'b-', 'LineWidth', 2);
hold on;
stem(t_sampled, x_sampled_original, 'r.', 'MarkerSize', 10);
xlabel('Time (s)');
ylabel('Amplitude');
title('Part 3: Original Signal (100 Hz) with Samples (Fs = 75 Hz)');
legend('Analog Signal', 'Samples');
grid on;
axis([-0.04 0.04 -3.5 3.5]);

% Aliased signal (Part 4)
subplot(2,1,2);
plot(t, xa_aliased, 'g-', 'LineWidth', 2);
hold on;
stem(t_sampled, x_sampled_aliased, 'r.', 'MarkerSize', 10);
xlabel('Time (s)');
ylabel('Amplitude');
title(['Part 4: Aliased Signal (' num2str(F_aliased) ' Hz) with Samples (Fs = 75 Hz)']);
legend('Analog Signal', 'Samples');
grid on;
axis([-0.04 0.04 -3.5 3.5]);

% Adjust layout
sgtitle('Comparison of Original and Aliased Signals');
