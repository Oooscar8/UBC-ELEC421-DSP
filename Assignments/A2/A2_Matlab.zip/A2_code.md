# Q1

## Part2

![ff74bf645fc16d5be8382b8a7f3351f](https://gitee.com/OooAlex/study_note/raw/master/img/202410232029585.png)

## Part3

![893434d97f30fd8c7abf18c57227e94](https://gitee.com/OooAlex/study_note/raw/master/img/202410232030905.png)

## Part4

![f7297f306a3052131ed415ed7464f8f](https://gitee.com/OooAlex/study_note/raw/master/img/202410232030812.png)



# Q3

## Part2

![a2dbb3a5580a3054dcb92382702ed44](https://gitee.com/OooAlex/study_note/raw/master/img/202410232031751.png)

## Part3

![7f2370452d073c60167e013836a89df](https://gitee.com/OooAlex/study_note/raw/master/img/202410232032336.png)



# Q5

## Part3

![8c9a187ba9b379e32b9e7008e8a6d20](https://gitee.com/OooAlex/study_note/raw/master/img/202410232033966.png)

## Part4

![1d58afb1f62de300116fe4102db937b](https://gitee.com/OooAlex/study_note/raw/master/img/202410232034682.png)

## Part5

![909d309ee3c2bc31a7b87451ca64674](https://gitee.com/OooAlex/study_note/raw/master/img/202410232034243.png)



# Q6

## Part2

![e5efe39b6b8c91e9e21dead8eb55b68](https://gitee.com/OooAlex/study_note/raw/master/img/202410232035017.png)

## Part3

![3bf6f1a808997172ffb186028bd96ad](https://gitee.com/OooAlex/study_note/raw/master/img/202410232036217.png)



# Q7

## Part3

![823ceb0e8476bb46de13ae95550b8ec](https://gitee.com/OooAlex/study_note/raw/master/img/202410232035367.png)