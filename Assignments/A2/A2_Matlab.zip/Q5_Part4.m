% Q5 Part 4

% Define parameters
N0 = 20;  % Period of the signal
omega0 = 2*pi/N0;  % Fundamental frequency

% Calculate DTFS coefficients
m = -N0/2:N0/2-1;  % Frequency index
Dm = zeros(size(m));

for k = 1:length(m)
    if m(k) == 1
        Dm(k) = 1/(2j);  % j is the imaginary unit in MATLAB
    elseif m(k) == -1
        Dm(k) = -1/(2j);
    else
        Dm(k) = 0;
    end
end

% Calculate omega values
omega = m * omega0;

% Plot amplitude spectrum
figure;
stem(omega/pi, abs(Dm), 'b', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('\Omega/\pi', 'FontSize', 12);
ylabel('|D_m|', 'FontSize', 12);
title('Amplitude Spectrum', 'FontSize', 14);
grid on;

% Customize the plot
xlim([-1 1]);
xticks(-1:0.5:1);
xticklabels({'-1', '-0.5', '0', '0.5', '1'});
ylim([0 0.6]);
yticks(0:0.1:0.5);
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.FontSize = 10;
box off;




