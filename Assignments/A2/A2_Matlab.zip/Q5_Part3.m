% Q5 Part 3 MATLAB code

% Define parameters
N0 = 20;  % Period of the signal
k = 0:2*N0-1;  % Sample indices for two periods

% Generate the discrete-time signal
x = sin(0.1*pi*k);

% Create the plot
figure;
stem(k, x, 'b', 'LineWidth', 1.5, 'MarkerSize', 6);
xlabel('k');
ylabel('x[k]');
title('Discrete-Time Sinusoid x[k] = sin(0.1\pik)');
grid on;

% Adjust axis for better visibility
xlim([0, 2*N0-1]);
ylim([-1.1, 1.1]);

% Add text to explain the signal
text(5, 0.8, 'x[k] = sin(0.1\pik)', 'FontSize', 10);

% Optionally, you can add a legend
legend('x[k]');
