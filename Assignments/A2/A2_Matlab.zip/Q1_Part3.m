% Time vector for continuous signal
t = -0.04:0.0001:0.04;

% Continuous signal
xa = 3*cos(100*pi*t);

% Sampling frequency
Fs = 75;

% Time vector for samples
t_sampled = -0.04:1/Fs:0.04;

% Sampled signal
x_sampled = 3*cos(100*pi*t_sampled);

% Plotting
figure('Position', [100, 100, 1000, 400]);
plot(t, xa, 'b-', 'LineWidth', 2); % Continuous signal
hold on;
stem(t_sampled, x_sampled, 'r.', 'MarkerSize', 10); % Sampled points

% Labels and title
xlabel('Time (s)');
ylabel('Amplitude');
title('Analog Signal with Samples (Fs = 75 Hz)');
legend('Analog Signal', 'Samples');
grid on;

axis([-0.04 0.04 -3.5 3.5]);
