% Q3 Part 2 MATLAB code

% Define parameters
Fs = 5000;  % Sampling frequency in Hz
n = 0:20;  % Sample indices (showing 21 samples)

% Generate the discrete-time signal
x = 3*cos(0.4*pi*n) + 5*sin(1.2*pi*n) + 10*cos(2.4*pi*n);

% Create the plot
figure;
stem(n, x, 'b', 'LineWidth', 1.5, 'MarkerSize', 6);
xlabel('n');
ylabel('x[n]');
title('Sampled Signal (Fs = 5000 Hz)');
grid on;

% Adjust axis for better visibility
xlim([0, 20]);  % Show all 21 samples
ylim([-20, 20]);  % Adjust y-axis range based on signal amplitude

% Add text to explain the signal components
text(2, 18, '3cos(0.4\pin) + 5sin(1.2\pin) + 10cos(2.4\pin)', 'FontSize', 10);

% Optionally, you can add a legend
legend('x[n]');



