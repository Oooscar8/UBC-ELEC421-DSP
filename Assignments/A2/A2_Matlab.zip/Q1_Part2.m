% Time vector for continuous signal
t = -0.05:0.0001:0.05;

% Continuous signal
xa = 3*cos(100*pi*t);

% Sampling frequency
Fs = 200;

% Time vector for samples
t_sampled = -0.05:1/Fs:0.05;

% Sampled signal
x_sampled = 3*cos(100*pi*t_sampled);

% Plotting
figure('Position', [100, 100, 1000, 400]);
plot(t, xa, 'b-', 'LineWidth', 2); % Continuous signal
hold on;
stem(t_sampled, x_sampled, 'r.', 'MarkerSize', 10); % Sampled points

% Labels and title
xlabel('Time (s)');
ylabel('Amplitude');
title('Analog Signal with Samples (Fs = 200 Hz)');
legend('Analog Signal', 'Samples');
grid on;

axis([-0.05 0.05 -3.5 3.5]);
