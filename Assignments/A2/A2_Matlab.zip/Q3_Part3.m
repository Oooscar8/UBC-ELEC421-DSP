% Q3 Part 3 MATLAB code

% Define parameters
Fs = 5000;  % Sampling frequency in Hz
t = 0:1/100000:0.004;  % Time vector for continuous signals (high resolution)
n = 0:20;  % Sample indices
t_sampled = n/Fs;  % Time points for samples

% Original signal
x_original = 3*cos(2000*pi*t) + 5*sin(6000*pi*t) + 10*cos(12000*pi*t);

% Sampled signal
x_sampled = 3*cos(2000*pi*t_sampled) + 5*sin(6000*pi*t_sampled) + 10*cos(12000*pi*t_sampled);

% Define our own sinc function
my_sinc = @(x) sin(pi*x)./(pi*x + eps);  % eps is added to avoid division by zero

% Ideal interpolation (reconstruction)
x_reconstructed = zeros(size(t));
for k = 1:length(t_sampled)
    x_reconstructed = x_reconstructed + x_sampled(k) * my_sinc(Fs * (t - t_sampled(k)));
end

% Create the plot
figure;
plot(t, x_original, 'b', 'LineWidth', 1.5);
hold on;
plot(t, x_reconstructed, 'r--', 'LineWidth', 1.5);
stem(t_sampled, x_sampled, 'g', 'LineWidth', 1.5, 'MarkerSize', 6);

% Customize the plot
xlabel('Time (s)');
ylabel('Amplitude');
title('Original, Sampled, and Reconstructed Signals (Fs = 5000 Hz)');
legend('Original Signal', 'Reconstructed Signal (Ideal Interpolation)', 'Samples');
grid on;

% Adjust axis for better visibility
xlim([0, 0.004]);  % Show first 4 ms
ylim([-20, 20]);   % Adjust y-axis range based on signal amplitude

% Add text to explain the aliasing effect
text(0.0005, 18, 'Aliasing due to undersampling', 'FontSize', 10);
