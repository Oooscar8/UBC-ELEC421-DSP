% Q7 Part 3

% Parameters
num_periods = 3;  % Number of periods to display
omega = linspace(0, 2*pi*num_periods, 1000);  % Extended frequency range
N = 5;  % Sequence length

% Calculate continuous |X(Ω)|
X_omega = 3 + 2*exp(-1j*omega) + exp(-1j*2*omega);
magnitude = abs(X_omega);

% Calculate DFT points for multiple periods
num_dft_points = N * num_periods;
r = 0:num_dft_points-1;
X_dft = zeros(1, num_dft_points);

for i = 1:num_dft_points
    r_val = mod(r(i), N);  % Use mod to handle periodicity
    X_dft(i) = 3 + 2*exp(-1j*2*pi*r_val/N) + exp(-1j*4*pi*r_val/N);
end

% Create the plot
figure;
% Plot continuous spectrum
plot(omega/(2*pi), magnitude, 'b-', 'LineWidth', 1.5);
hold on;

% Plot DFT points
stem(r/N, abs(X_dft), 'r.', 'MarkerSize', 20);

% Customize plot
grid on;
xlabel('\Omega/(2\pi)');
ylabel('|X(\Omega)|');
title('Amplitude Spectrum and DFT Points');
legend('Continuous |X(\Omega)|', 'DFT Points');
xlim([0 num_periods]);

% Add period labels
for i = 1:num_periods
    text((i-0.5), max(magnitude)*1.05, ['Period ' num2str(i)], ...
        'HorizontalAlignment', 'center');
end