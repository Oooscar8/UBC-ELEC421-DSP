% Q6 Part 2

% Parameters
N0 = 50;  % Fundamental period
M = 4;    % Pulse width parameter
k = 0:50; % k values for plotting

% Generate the pulse signal
x = zeros(size(k));
for ki = 1:length(k)
    % Get the position within one period
    k_mod = mod(k(ki), N0);
    
    % Set pulse to 1 if k is within [-M,M] or [N0-M,N0+M]
    if (k_mod <= M) || (k_mod >= N0-M)
        x(ki) = 1;
    end
end

% Calculate DTFS coefficients
N = N0;  % Period for DTFS
D = zeros(N, 1);
for m = 0:N-1
    sum = 0;
    for n = 0:N-1
        sum = sum + x(n+1) * exp(-1j*2*pi*m*n/N);
    end
    D(m+1) = sum/N;
end

% Create subplot for both signals
figure;

% Plot time domain signal
subplot(2,1,1);
stem(k, x, 'filled');
grid on;
xlabel('k');
ylabel('x[k]');
title(['Pulse Signal (N₀ = ', num2str(N0), ', M = ', num2str(M), ')']);
xlim([0 50]);
ylim([-0.2 1.2]);

% Plot amplitude spectrum
subplot(2,1,2);
stem(0:N-1, abs(D), 'filled');
grid on;
xlabel('m');
ylabel('|D_m|');
title('Amplitude Spectrum');
xlim([0 N-1]);